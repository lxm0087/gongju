<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_gylm`;");
E_C("CREATE TABLE `lm_ecms_gylm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ttid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `onclick` int(10) unsigned NOT NULL DEFAULT '0',
  `plnum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `totaldown` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `newspath` char(20) NOT NULL DEFAULT '',
  `filename` char(36) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL DEFAULT '',
  `firsttitle` tinyint(1) NOT NULL DEFAULT '0',
  `isgood` tinyint(1) NOT NULL DEFAULT '0',
  `ispic` tinyint(1) NOT NULL DEFAULT '0',
  `istop` tinyint(1) NOT NULL DEFAULT '0',
  `isqf` tinyint(1) NOT NULL DEFAULT '0',
  `ismember` tinyint(1) NOT NULL DEFAULT '0',
  `isurl` tinyint(1) NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userfen` smallint(5) unsigned NOT NULL DEFAULT '0',
  `titlefont` char(14) NOT NULL DEFAULT '',
  `titleurl` char(200) NOT NULL DEFAULT '',
  `stb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `fstb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `restb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `keyboard` char(80) NOT NULL DEFAULT '',
  `title` char(100) NOT NULL DEFAULT '',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `titlepic` char(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `newstime` (`newstime`),
  KEY `ttid` (`ttid`),
  KEY `firsttitle` (`firsttitle`),
  KEY `isgood` (`isgood`),
  KEY `ispic` (`ispic`),
  KEY `useridis` (`userid`,`ismember`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_gylm` values('11','80','0','0','0','0','2016-12-05','11','1','admin','0','0','1','0','0','0','1','1480900237','1481076256','1','0','0','','/s/SdlLiposuctiona/index.html','1','1','1','','360°水动力吸脂','1480900227','/d/file/zhuanti/zxmr/2016-12-05/25bee9ffde9c637aa05efc1db219c19c.png');");
E_D("replace into `lm_ecms_gylm` values('10','80','0','0','0','0','2016-12-05','10','1','admin','0','0','1','0','0','0','1','1480900180','1481076263','1','0','0','','/s/UsingASpecial/index.html','1','1','1','','什么样的鼻子好看？','1480900094','/d/file/zhuanti/zxmr/2016-12-05/a9bc07d8cfbabb3d6b9bf0e23ec6a788.png');");
E_D("replace into `lm_ecms_gylm` values('9','80','0','0','0','0','2016-12-05','9','1','admin','0','0','1','0','0','0','1','1480900092','1481076270','1','0','0','','/s/BeautifulEyes/index.html','1','1','1','','三重美塑 眼整形','1480900067','/d/file/zhuanti/zxmr/2016-12-05/5109dc97b3570394046f0e70b58616f8.png');");
E_D("replace into `lm_ecms_gylm` values('12','80','0','0','0','0','2016-12-05','12','1','admin','0','0','1','0','0','0','1','1480900257','1481076250','1','0','0','','/s/CarvedEyesd/index.html','1','1','1','','如何选择 双眼皮手术方式？','1480900239','/d/file/zhuanti/zxmr/2016-12-05/ddb5011182bbb95c6a8bfc24db339caf.png');");
E_D("replace into `lm_ecms_gylm` values('13','80','0','0','0','0','2016-12-05','13','1','admin','0','0','1','0','0','0','1','1480900274','1481076244','1','0','0','','/s/BeautifulBosoma/index.html','1','1','1','','自体活细胞美胸','1480900259','/d/file/zhuanti/zxmr/2016-12-05/fc26f035748077f999ac0e80bea808eb.png');");
E_D("replace into `lm_ecms_gylm` values('14','80','0','0','0','0','2016-12-05','14','1','admin','0','0','1','0','0','0','1','1480900313','1481076234','1','0','0','','/s/BreastImplant/index.html','1','1','1','','U弧弹态隆胸','1480900276','/d/file/zhuanti/zxmr/2016-12-05/cfe1f7823886d11253b0d9ba579c69be.png');");
E_D("replace into `lm_ecms_gylm` values('15','80','0','0','0','0','2016-12-05','15','1','admin','0','0','1','0','0','0','1','1480900330','1481076228','1','0','0','','/s/ChangeFacea/index.html','1','1','1','','黄金改脸型','1480900315','/d/file/zhuanti/zxmr/2016-12-05/45495f43bcdd055ac1187bde709723ba.png');");
E_D("replace into `lm_ecms_gylm` values('16','80','0','0','0','0','2016-12-05','16','1','admin','0','0','1','0','0','0','1','1480900347','1481076220','1','0','0','','/s/CarvedEyesc/index.html','1','1','1','','韩式微创双眼皮','1480900332','/d/file/zhuanti/zxmr/2016-12-05/05c05aa72800943d38a5d89624ae52d9.png');");
E_D("replace into `lm_ecms_gylm` values('17','80','0','0','0','0','2016-12-05','17','1','admin','0','0','1','0','0','0','1','1480900381','1481076210','1','0','0','','/s/RemoveEyeBaga/index.html','1','1','1','','韩式无痕祛眼袋','1480900350','/d/file/zhuanti/zxmr/2016-12-05/11488dc20370d236e76f8bcdff549b7d.png');");
E_D("replace into `lm_ecms_gylm` values('18','80','0','0','0','0','2016-12-05','18','1','admin','0','0','1','0','0','0','1','1480900402','1481076203','1','0','0','','/s/Bromhidrosis/index.html','1','1','1','','纳米微创腋臭根除术','1480900383','/d/file/zhuanti/zxmr/2016-12-05/38fe566cf1dc34b1bb84e96cd4d7e753.png');");
E_D("replace into `lm_ecms_gylm` values('19','80','0','0','0','0','2016-12-05','19','1','admin','0','0','1','0','0','0','1','1480900424','1481076170','1','0','0','','/s/BreastImplanta/index.html','1','1','1','','U弧立体美胸','1480900404','/d/file/zhuanti/zxmr/2016-12-05/6a1dc78ead5930d67d26ea8ef92826b5.png');");
E_D("replace into `lm_ecms_gylm` values('20','80','0','0','0','0','2016-12-05','20','1','admin','0','0','1','0','0','0','1','1480900445','1481076162','1','0','0','','/s/Liposuction/index.html','1','1','1','','水动力螺旋吸脂','1480900426','/d/file/zhuanti/zxmr/2016-12-05/de1957b17962a532b0f70178a3e00543.png');");
E_D("replace into `lm_ecms_gylm` values('21','80','0','0','0','0','2016-12-05','21','1','admin','0','0','1','0','0','0','1','1480900459','1481076155','1','0','0','','/s/Rhinoplastyc/index.html','1','1','1','','多维美雕隆鼻','1480900447','/d/file/zhuanti/zxmr/2016-12-05/2ae2a111fe5951bfc4aa053c6a2d1466.png');");
E_D("replace into `lm_ecms_gylm` values('22','80','0','0','0','0','2016-12-05','22','1','admin','0','0','1','0','0','0','1','1480900485','1481076149','1','0','0','','/s/CarvedEyese/index.html','1','1','1','','韩式精雕双眼皮','1480900461','/d/file/zhuanti/zxmr/2016-12-05/55af335d0a0f86638f4d76efcb3a702d.png');");
E_D("replace into `lm_ecms_gylm` values('23','81','0','0','0','0','2016-12-05','23','1','admin','0','0','1','0','0','0','1','1480900556','1481076343','1','0','0','','/s/VervetDolla/index.html','1','1','1','','黑脸娃娃','1480900539','/d/file/zhuanti/pfmr/2016-12-05/124307cbd066a0c3ad9fef437912a6a2.png');");
E_D("replace into `lm_ecms_gylm` values('24','81','0','0','0','0','2016-12-05','24','1','admin','0','0','1','0','0','0','1','1480900570','1481076337','1','0','0','','/s/FreckleRemovinga/index.html','1','1','1','','祛斑需要多少钱？','1480900558','/d/file/zhuanti/pfmr/2016-12-05/20921c0e5d66f0a3e858a959f60886a7.png');");
E_D("replace into `lm_ecms_gylm` values('25','81','0','0','0','0','2016-12-05','25','1','admin','0','0','1','0','0','0','1','1480900587','1481076332','1','0','0','','/s/GlxfAcneTreatmenta/index.html','1','1','1','','光力雪肤祛痘','1480900572','/d/file/zhuanti/pfmr/2016-12-05/ffc17658f9001fc86b0263fa0ee3e1ec.png');");
E_D("replace into `lm_ecms_gylm` values('26','81','0','0','0','0','2016-12-05','26','1','admin','0','0','1','0','0','0','1','1480900611','1481076325','1','0','0','','/s/FreckleRemovingb/index.html','1','1','1','','美国C8柔肤镭射祛雀斑','1480900589','/d/file/zhuanti/pfmr/2016-12-05/49d14c7e85f442adb6ee3251fa91b0c5.png');");
E_D("replace into `lm_ecms_gylm` values('27','81','0','0','0','0','2016-12-05','27','1','admin','0','0','1','0','0','0','1','1480900636','1481076313','1','0','0','','/s/OPTKingStyleb/index.html','1','1','1','','OPT王者风范','1480900613','/d/file/zhuanti/pfmr/2016-12-05/3f808d072dde4aad00d4222f150ae461.png');");
E_D("replace into `lm_ecms_gylm` values('28','81','0','0','0','0','2016-12-05','28','1','admin','0','0','1','0','0','0','1','1480900657','1481076308','1','0','0','','/s/HairRemoval/index.html','1','1','1','','冷触雪肤脱毛 纵享丝滑肌肤','1480900638','/d/file/zhuanti/pfmr/2016-12-05/110a39071b0a46e646bfdfba9e59c5f1.png');");
E_D("replace into `lm_ecms_gylm` values('29','81','0','0','0','0','2016-12-05','29','1','admin','0','0','1','0','0','0','1','1480900671','1481076303','1','0','0','','/s/NsxRhytidectomy/index.html','1','1','1','','莱美逆时星除皱','1480900659','/d/file/zhuanti/pfmr/2016-12-05/6fd714de71ad64b126dad489579f62a2.png');");
E_D("replace into `lm_ecms_gylm` values('30','81','0','0','0','0','2016-12-05','30','1','admin','0','0','1','0','0','0','1','1480900694','1481076298','1','0','0','','/s/FreckleRemovingd/index.html','1','1','1','','双核光祛斑','1480900673','/d/file/zhuanti/pfmr/2016-12-05/2af0ea711acf5a01f1a3bca98a6f31fe.png');");
E_D("replace into `lm_ecms_gylm` values('31','81','0','0','0','0','2016-12-05','31','1','admin','0','0','1','0','0','0','1','1480900709','1481076292','1','0','0','','/s/RemoveBirthmarksa/index.html','1','1','1','','激光祛胎记','1480900696','/d/file/zhuanti/pfmr/2016-12-05/afc3c6b31673cd8896e0ddbc790a5b26.png');");
E_D("replace into `lm_ecms_gylm` values('32','82','0','0','0','0','2016-12-05','32','1','admin','0','0','1','0','0','0','1','1480900749','1481621257','1','0','0','','/s/BotoxLiftPin/index.html','1','1','1','','Botox瘦脸针','1480900736','/d/file/zhuanti/vzx/2016-12-05/24f8c072dc9603980df4b16c66667a28.png');");
E_D("replace into `lm_ecms_gylm` values('33','82','0','0','0','0','2016-12-05','33','1','admin','0','0','1','0','0','0','1','1480900763','1481076372','1','0','0','','/s/YoungerVulture/index.html','1','1','1','','年轻化面雕','1480900751','/d/file/zhuanti/vzx/2016-12-05/7d9e13002915a75fd6387444fc0fb94b.png');");
E_D("replace into `lm_ecms_gylm` values('34','82','0','0','0','0','2016-12-05','34','1','admin','0','0','1','0','0','0','1','1480900778','1481076366','1','0','0','','/s/FaceLiftNeedled/index.html','1','1','1','','针功夫精微整形','1480900765','/d/file/zhuanti/vzx/2016-12-05/6420cb1bfc53f0ad58822d9dd01a4af9.png');");
E_D("replace into `lm_ecms_gylm` values('35','82','0','0','0','0','2016-12-05','35','1','admin','0','0','1','0','0','0','1','1480900805','1481076362','1','0','0','','/s/BotoxKreotoxina/index.html','1','1','1','','Botox抗衰老','1480900780','/d/file/zhuanti/vzx/2016-12-05/292465a9d4cc08e9b3f6bc11bd1d2e73.png');");
E_D("replace into `lm_ecms_gylm` values('36','82','0','0','0','0','2016-12-05','36','1','admin','0','0','1','0','0','0','1','1480900823','1481076358','1','0','0','','/s/FaceLiftNeedlea/index.html','1','1','1','','Botox','1480900807','/d/file/zhuanti/vzx/2016-12-05/5cabcca028328044cc64bd3d975a0552.png');");
E_D("replace into `lm_ecms_gylm` values('37','83','0','0','0','0','2016-12-05','37','1','admin','0','0','1','0','0','0','1','1480900918','1482915213','1','0','0','','/s/DentalCorrection/index.html','1','1','1','','隐形牙齿矫正','1480900904','/d/file/zhuanti/kqmr/2016-12-05/014619cc8117780a8b326832bc0f1ac4.png');");
E_D("replace into `lm_ecms_gylm` values('38','83','0','0','0','0','2016-12-05','38','1','admin','0','0','1','0','0','0','1','1480900935','1482915216','1','0','0','','/s/Teethas/index.html','1','1','1','','皓齿仿生美容冠','1480900921','/d/file/zhuanti/kqmr/2016-12-05/b25d9186a79496dbaef0913088b47130.png');");

@include("../../inc/footer.php");
?>