<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_gylm_data_1`;");
E_C("CREATE TABLE `lm_ecms_gylm_data_1` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `keyid` char(255) NOT NULL DEFAULT '',
  `dokey` tinyint(1) NOT NULL DEFAULT '0',
  `newstempid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `closepl` tinyint(1) NOT NULL DEFAULT '0',
  `haveaddfen` tinyint(1) NOT NULL DEFAULT '0',
  `infotags` char(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_gylm_data_1` values('11','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('10','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('9','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('12','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('13','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('14','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('15','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('16','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('17','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('18','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('19','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('20','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('21','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('22','80','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('23','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('24','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('25','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('26','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('27','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('28','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('29','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('30','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('31','81','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('32','82','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('33','82','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('34','82','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('35','82','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('36','82','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('37','83','','0','0','0','0','');");
E_D("replace into `lm_ecms_gylm_data_1` values('38','83','','0','0','0','0','');");

@include("../../inc/footer.php");
?>