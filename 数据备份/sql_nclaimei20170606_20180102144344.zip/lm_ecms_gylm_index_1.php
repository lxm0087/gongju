<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_gylm_index`;");
E_C("CREATE TABLE `lm_ecms_gylm_index` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `checked` (`checked`),
  KEY `newstime` (`newstime`),
  KEY `truetime` (`truetime`,`id`),
  KEY `havehtml` (`classid`,`truetime`,`havehtml`,`checked`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_gylm_index` values('11','80','1','1480900227','1480900237','1481076256','1');");
E_D("replace into `lm_ecms_gylm_index` values('10','80','1','1480900094','1480900180','1481076263','1');");
E_D("replace into `lm_ecms_gylm_index` values('9','80','1','1480900067','1480900092','1481076270','1');");
E_D("replace into `lm_ecms_gylm_index` values('12','80','1','1480900239','1480900257','1481076250','1');");
E_D("replace into `lm_ecms_gylm_index` values('13','80','1','1480900259','1480900274','1481076244','1');");
E_D("replace into `lm_ecms_gylm_index` values('14','80','1','1480900276','1480900313','1481076234','1');");
E_D("replace into `lm_ecms_gylm_index` values('15','80','1','1480900315','1480900330','1481076228','1');");
E_D("replace into `lm_ecms_gylm_index` values('16','80','1','1480900332','1480900347','1481076220','1');");
E_D("replace into `lm_ecms_gylm_index` values('17','80','1','1480900350','1480900381','1481076210','1');");
E_D("replace into `lm_ecms_gylm_index` values('18','80','1','1480900383','1480900402','1481076203','1');");
E_D("replace into `lm_ecms_gylm_index` values('19','80','1','1480900404','1480900424','1481076170','1');");
E_D("replace into `lm_ecms_gylm_index` values('20','80','1','1480900426','1480900445','1481076162','1');");
E_D("replace into `lm_ecms_gylm_index` values('21','80','1','1480900447','1480900459','1481076155','1');");
E_D("replace into `lm_ecms_gylm_index` values('22','80','1','1480900461','1480900485','1481076149','1');");
E_D("replace into `lm_ecms_gylm_index` values('23','81','1','1480900539','1480900556','1481076343','1');");
E_D("replace into `lm_ecms_gylm_index` values('24','81','1','1480900558','1480900570','1481076337','1');");
E_D("replace into `lm_ecms_gylm_index` values('25','81','1','1480900572','1480900587','1481076332','1');");
E_D("replace into `lm_ecms_gylm_index` values('26','81','1','1480900589','1480900611','1481076325','1');");
E_D("replace into `lm_ecms_gylm_index` values('27','81','1','1480900613','1480900636','1481076313','1');");
E_D("replace into `lm_ecms_gylm_index` values('28','81','1','1480900638','1480900657','1481076308','1');");
E_D("replace into `lm_ecms_gylm_index` values('29','81','1','1480900659','1480900671','1481076303','1');");
E_D("replace into `lm_ecms_gylm_index` values('30','81','1','1480900673','1480900694','1481076298','1');");
E_D("replace into `lm_ecms_gylm_index` values('31','81','1','1480900696','1480900709','1481076292','1');");
E_D("replace into `lm_ecms_gylm_index` values('32','82','1','1480900736','1480900749','1481621257','1');");
E_D("replace into `lm_ecms_gylm_index` values('33','82','1','1480900751','1480900763','1481076372','1');");
E_D("replace into `lm_ecms_gylm_index` values('34','82','1','1480900765','1480900778','1481076366','1');");
E_D("replace into `lm_ecms_gylm_index` values('35','82','1','1480900780','1480900805','1481076362','1');");
E_D("replace into `lm_ecms_gylm_index` values('36','82','1','1480900807','1480900823','1481076358','1');");
E_D("replace into `lm_ecms_gylm_index` values('37','83','1','1480900904','1480900918','1482915213','1');");
E_D("replace into `lm_ecms_gylm_index` values('38','83','1','1480900921','1480900935','1482915216','1');");

@include("../../inc/footer.php");
?>