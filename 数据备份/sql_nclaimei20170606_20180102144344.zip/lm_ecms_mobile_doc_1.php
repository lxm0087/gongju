<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_mobile_doc`;");
E_C("CREATE TABLE `lm_ecms_mobile_doc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ttid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `onclick` int(10) unsigned NOT NULL DEFAULT '0',
  `plnum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `totaldown` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `newspath` char(20) NOT NULL DEFAULT '',
  `filename` char(36) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL DEFAULT '',
  `firsttitle` tinyint(1) NOT NULL DEFAULT '0',
  `isgood` tinyint(1) NOT NULL DEFAULT '0',
  `ispic` tinyint(1) NOT NULL DEFAULT '0',
  `istop` tinyint(1) NOT NULL DEFAULT '0',
  `isqf` tinyint(1) NOT NULL DEFAULT '0',
  `ismember` tinyint(1) NOT NULL DEFAULT '0',
  `isurl` tinyint(1) NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userfen` smallint(5) unsigned NOT NULL DEFAULT '0',
  `titlefont` char(14) NOT NULL DEFAULT '',
  `titleurl` char(200) NOT NULL DEFAULT '',
  `stb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `fstb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `restb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `keyboard` char(80) NOT NULL DEFAULT '',
  `title` char(100) NOT NULL DEFAULT '',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `titlepic` char(120) NOT NULL DEFAULT '',
  `ftitle` char(120) NOT NULL DEFAULT '',
  `smalltext` char(255) NOT NULL DEFAULT '',
  `diggtop` int(11) NOT NULL DEFAULT '0',
  `experttext` char(255) NOT NULL DEFAULT '',
  `expertimg` char(120) NOT NULL DEFAULT '',
  `expertjs` char(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `newstime` (`newstime`),
  KEY `ttid` (`ttid`),
  KEY `firsttitle` (`firsttitle`),
  KEY `isgood` (`isgood`),
  KEY `ispic` (`ispic`),
  KEY `useridis` (`userid`,`ismember`)
) ENGINE=MyISAM AUTO_INCREMENT=811 DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_mobile_doc` values('810','177','0','0','0','0','2017-10-16','810','1','admin','0','0','1','0','0','0','0','1508139069','1508139069','1','0','0','','http://m.nclaimei.com/ymgl/zjgl/2017-10-16/810.html','1','1','1','','彭圣海','1498036960','http://www.nclaimei.com/d/file/MobileCom/ymgl/zjgl/2017-10-16/207e8a70155ed909e66aaabc6527d700.jpg','技术院长','彭圣海院长坚持不断学习，总保持着一种谦逊、虚心求教,诚恳严谨的态度，每年不定期赴美、澳、韩等多国进行学术交流活动，吸收国际先进的整形美容理念，尤其在眼、鼻部整形方面有着独特的造诣，曾与多位国内外眼鼻整形大咖同台竞技，凭借其扎实的专业功底深受同行们的赞誉，素有“面雕小王子”之称','0','擅长项目：眼部综合整形、鼻部综合整形、面部整形等','http://www.nclaimei.com/d/file/MobileCom/ymgl/zjgl/2017-10-16/9de80e538061ad03f238c76dcfe5b551.jpg','');");

@include("../../inc/footer.php");
?>