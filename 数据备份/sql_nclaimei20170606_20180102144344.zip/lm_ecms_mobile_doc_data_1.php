<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_mobile_doc_data`;");
E_C("CREATE TABLE `lm_ecms_mobile_doc_data` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `keyid` varchar(255) NOT NULL DEFAULT '',
  `dokey` tinyint(1) NOT NULL DEFAULT '0',
  `newstempid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `closepl` tinyint(1) NOT NULL DEFAULT '0',
  `haveaddfen` tinyint(1) NOT NULL DEFAULT '0',
  `infotags` varchar(80) NOT NULL DEFAULT '',
  `writer` varchar(30) NOT NULL DEFAULT '',
  `befrom` varchar(60) NOT NULL DEFAULT '',
  `newstext` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_mobile_doc_data` values('810','177','','1','0','0','0','','','','<ul>\r\n    <li>\r\n    <h1>专家简介</h1>\r\n    <p>毕业于南方医科大学，获整形外科硕士学位。从事整形美容十多余年，具有丰富的临床经验，并拥有国际化的审美理念及眼界，倡导根据个人特点进行个性化精致面容设计。手术操作细腻精准，效果自然传神，凭借高度的责任心深得求美人士追捧。 彭圣海院长坚持不断学习，总保持着一种谦逊、虚心求教,诚恳严谨的态度，每年不定期赴美、澳、韩等多国进行学术交流活动，吸收国际先进的整形美容理念，尤其在眼、鼻部整形方面有着独特的造诣，曾与多位国内外眼鼻整形大咖同台竞技，凭借其扎实的专业功底深受同行们的赞誉，素有&ldquo;面雕小王子&rdquo;之称。</p>\r\n    </li>\r\n    <li>\r\n    <h1>个人荣誉</h1>\r\n    <p>&middot;  南昌莱美美容医院技术院长 <br />\r\n    &middot;  中国医师协会美容与整形医师分会会员 <br />\r\n    &middot;  &lt;&lt;中国美容医学&gt;&gt;杂志参编者 <br />\r\n    &middot;  中国十佳青年技术派杰出整形医师</p>\r\n    </li>\r\n    <li>\r\n    <h1>擅长项目</h1>\r\n    <p>眼部综合整形、鼻部综合整形、面部整形等</p>\r\n    </li>\r\n</ul>');");

@include("../../inc/footer.php");
?>