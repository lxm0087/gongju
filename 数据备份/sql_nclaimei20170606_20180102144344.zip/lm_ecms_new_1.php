<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_new`;");
E_C("CREATE TABLE `lm_ecms_new` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ttid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `onclick` int(10) unsigned NOT NULL DEFAULT '0',
  `plnum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `totaldown` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `newspath` char(20) NOT NULL DEFAULT '',
  `filename` char(36) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL DEFAULT '',
  `firsttitle` tinyint(1) NOT NULL DEFAULT '0',
  `isgood` tinyint(1) NOT NULL DEFAULT '0',
  `ispic` tinyint(1) NOT NULL DEFAULT '0',
  `istop` tinyint(1) NOT NULL DEFAULT '0',
  `isqf` tinyint(1) NOT NULL DEFAULT '0',
  `ismember` tinyint(1) NOT NULL DEFAULT '0',
  `isurl` tinyint(1) NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userfen` smallint(5) unsigned NOT NULL DEFAULT '0',
  `titlefont` char(14) NOT NULL DEFAULT '',
  `titleurl` char(200) NOT NULL DEFAULT '',
  `stb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `fstb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `restb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `keyboard` char(80) NOT NULL DEFAULT '',
  `title` char(100) NOT NULL DEFAULT '',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `titlepic` char(120) NOT NULL DEFAULT '',
  `ftitle` char(120) NOT NULL DEFAULT '',
  `smalltext` char(255) NOT NULL DEFAULT '',
  `diggtop` int(11) NOT NULL DEFAULT '0',
  `experttext` mediumtext NOT NULL,
  `expertimg` char(120) NOT NULL DEFAULT '',
  `expertjs` char(120) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `newstime` (`newstime`),
  KEY `ttid` (`ttid`),
  KEY `firsttitle` (`firsttitle`),
  KEY `isgood` (`isgood`),
  KEY `ispic` (`ispic`),
  KEY `useridis` (`userid`,`ismember`)
) ENGINE=MyISAM AUTO_INCREMENT=421 DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_new` values('395','187','0','0','0','0','2017-05-25','395','1','admin','0','0','1','0','0','0','1','1495691835','1503036777','1','0','0','','http://www.nclmmryy.com/','1','1','1','','做最美的自己','1495691786','http://www.nclaimei.com/d/file/lmmryyCom/menu/bangl/2017-05-25/7d60b46aa4f0c16901743d453572b442.jpg','','','0','','','');");
E_D("replace into `lm_ecms_new` values('396','187','0','0','0','0','2017-05-25','396','1','admin','0','0','1','0','0','0','1','1495692022','1503037271','1','0','0','','http://www.nclmmryy.com/','1','1','1','','莱美医院外景','1503037268','http://www.nclaimei.com/d/file/lmmryyCom/menu/bangl/2017-08-18/ca28661ae2b030c215a8c0112332078c.jpg','','','0','','','');");
E_D("replace into `lm_ecms_new` values('397','189','0','0','0','0','2017-05-27','397','1','admin','0','0','0','0','0','0','1','1495851161','1496543703','1','0','0','','http://www.nclmmryy.com/sygl/lxwm/','1','1','1','','联系我们','1495851142','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('398','189','0','0','0','0','2017-05-27','398','1','admin','0','0','0','0','0','0','1','1495851175','1503035406','1','0','0','','/','1','1','1','','在线留言','1495851165','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('420','187','0','0','0','0','2017-08-18','420','1','admin','0','0','1','0','0','0','1','1503036637','1503036785','1','0','0','','http://www.nclmmryy.com/','1','1','1','','莱美医院大厅','1503036621','http://www.nclaimei.com/d/file/lmmryyCom/menu/bangl/2017-08-18/8121b1b2ff952c9b5d719011264e8dd9.jpg','','','0','','','');");
E_D("replace into `lm_ecms_new` values('399','189','0','0','0','0','2017-05-27','399','1','admin','0','0','0','0','0','0','0','1495851189','1497950108','1','0','0','','http://www.nclmmryy.com/menu/topnav/2017-05-27/399.html','1','1','1','','招贤纳士','1495851178','','','招聘保安一名招聘保洁一名招聘仓管一名招聘护士多名联系电话123456789','0','','','');");
E_D("replace into `lm_ecms_new` values('400','189','0','0','0','0','2017-05-27','400','1','admin','0','0','0','0','0','0','1','1495851196','1496543688','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/','1','1','1','','莱美动态','1495851191','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('401','189','0','0','0','0','2017-05-27','401','1','admin','0','0','0','0','0','0','1','1495851203','1496543674','1','0','0','','http://www.nclmmryy.com/sygl/qywh/','1','1','1','','企业文化','1495851198','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('402','189','0','0','0','0','2017-05-27','402','1','admin','0','0','0','0','0','0','1','1495851215','1496543662','1','0','0','','http://www.nclmmryy.com/sygl/lmjj/','1','1','1','','关于莱美','1495851205','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('403','189','0','0','0','0','2017-05-27','403','1','admin','0','0','0','0','0','0','1','1495851223','1495851237','1','0','0','','http://www.nclmmryy.com/','1','1','1','','首页','1495851220','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('404','190','0','0','0','0','2017-05-27','404','1','admin','0','0','1','0','0','0','0','1495851955','1503795831','1','0','0','','http://www.nclmmryy.com/sygl/lmjj/2017-05-27/404.html','1','1','1','','莱美简介','1495851928','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmjj/2017-08-18/66564d9666276949df2bd8c5909ebbdd.jpg','','南昌莱美美容医院，2010年入驻江西南昌，是目前国内规模及影响力的高端整形美容品牌。典雅的环境，尊崇的个性化服务，无与伦比的技术及效果，已成为明星名媛的推荐机构。','0','南昌莱美美容医院，2010年入驻江西南昌，是目前国内规模及影响力的高端整形美容品牌。典雅的环境，尊崇的个性化服务，无与伦比的技术及效果，已成为明星名媛的推荐机构。','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmjj/2017-06-05/ae35f38d66e190ddf5f05c04f8b86b61.jpg','');");
E_D("replace into `lm_ecms_new` values('405','191','0','0','0','0','2017-05-31','405','1','admin','0','0','0','0','0','0','0','1496216507','1496644888','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/2017-05-31/405.html','1','1','1','','整形须知：整形医院的5个专业资质','1496216731','','',' 时下在专业整形医院进进出出的人越来越多，这说明整形美容业的发展越发蓬勃。但是需要警醒的是，有相当一部分人在非专业整形医院接受整形手术后出现后遗症，甚至有些在手术过程','0','','','');");
E_D("replace into `lm_ecms_new` values('406','191','0','0','0','0','2017-05-31','406','1','admin','0','0','0','0','0','0','0','1496216517','1496216729','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/2017-05-31/406.html','1','1','1','','开运整形攻略 莱美专家讲解面相与','1496216727','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('407','191','0','0','0','0','2017-05-31','407','1','admin','0','0','0','0','0','0','0','1496216526','1496216725','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/2017-05-31/407.html','1','1','1','','多维美雕鼻部整形 中韩明星美鼻首','1496216723','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('408','191','0','0','0','0','2017-05-31','408','1','admin','0','0','0','0','0','0','0','1496216531','1496216719','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/2017-05-31/408.html','1','1','1','','开运整形攻略 莱美专家讲解面相与','1496216718','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('409','191','0','0','0','0','2017-05-31','409','1','admin','0','0','0','0','0','0','0','1496216538','1496216716','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/2017-05-31/409.html','1','1','1','','多维美雕鼻部整形 中韩明星美鼻首','1496216714','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('410','191','0','0','0','0','2017-05-31','410','1','admin','0','0','0','0','0','0','0','1496216543','1496216707','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/2017-05-31/410.html','1','1','1','','莱美针功夫 精微雕琢“面子工程“','1496216706','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('411','191','0','0','0','0','2017-05-31','411','1','admin','0','0','0','0','0','0','0','1496216548','1496216703','1','0','0','','http://www.nclmmryy.com/sygl/lmdt/2017-05-31/411.html','1','1','1','','多维美雕鼻整形 挺秀美鼻宛若天生','1496216699','','','','0','','','');");
E_D("replace into `lm_ecms_new` values('412','192','0','0','0','0','2017-06-03','412','1','admin','0','0','1','0','0','0','0','1496469596','1496643686','1','0','0','','http://www.nclmmryy.com/sygl/lmry/2017-06-03/412.html','1','1','1','','美国Natrelle全球指定使用单位','1496469587','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmry/2017-06-05/64ef3b2a39327c999589c0526c8221cc.png','','','0','','','');");
E_D("replace into `lm_ecms_new` values('413','192','0','0','0','0','2017-06-03','413','1','admin','0','0','1','0','0','0','0','1496469602','1496643677','1','0','0','','http://www.nclmmryy.com/sygl/lmry/2017-06-03/413.html','1','1','1','','以色列飞顿激光全球科研合作伙伴','1496469598','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmry/2017-06-05/d4f2bb8049b3ce6fd3438f9cb0b404cd.png','','','0','','','');");
E_D("replace into `lm_ecms_new` values('414','192','0','0','0','0','2017-06-03','414','1','admin','0','0','1','0','0','0','0','1496469614','1496643667','1','0','0','','http://www.nclmmryy.com/sygl/lmry/2017-06-03/414.html','1','1','1','','美国科医人激光中国临床培训中心','1496469604','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmry/2017-06-05/83ba65c7e9f8115f9f0e0b11d9307462.png','','','0','','','');");
E_D("replace into `lm_ecms_new` values('415','192','0','0','0','0','2017-06-03','415','1','admin','0','0','1','0','0','0','0','1496469621','1496643647','1','0','0','','http://www.nclmmryy.com/sygl/lmry/2017-06-03/415.html','1','1','1','','美国曼托假体授权指定使用单位','1496469616','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmry/2017-06-05/e15c86cf3db7a1bfd1afc701f03a28cd.png','','','0','','','');");
E_D("replace into `lm_ecms_new` values('416','192','0','0','0','0','2017-06-03','416','1','admin','0','0','1','0','0','0','0','1496469626','1496643633','1','0','0','','http://www.nclmmryy.com/sygl/lmry/2017-06-03/416.html','1','1','1','','中美合作激光美容技术交流中心','1496469623','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmry/2017-06-05/5d88cac6eb3ebfe43563d5ce2a8bfe5c.png','','','0','','','');");
E_D("replace into `lm_ecms_new` values('417','192','0','0','0','0','2017-06-03','417','1','admin','0','0','1','0','0','0','0','1496469632','1496643523','1','0','0','','http://www.nclmmryy.com/sygl/lmry/2017-06-03/417.html','1','1','1','','韩国汉城整形医院技术合作医院','1496469629','http://www.nclaimei.com/d/file/lmmryyCom/sygl/lmry/2017-06-05/f72f084ff2cc4cacc487f28b8fcf091e.png','','','0','','','');");
E_D("replace into `lm_ecms_new` values('418','193','0','0','0','0','2017-06-03','418','1','admin','0','0','0','0','0','0','1','1496470224','1496709829','1','0','0','','/','1','1','1','','企业文化','1496470152','','','<dd>核心价值观：</dd> \r\n<dd>诚实守信 勤奋创新</dd> \r\n<dd>莱美使命：</dd> \r\n<dd>推动中国医美行业的进步和发展</dd>','0','','','');");
E_D("replace into `lm_ecms_new` values('419','194','0','0','0','0','2017-06-03','419','1','admin','0','0','0','0','0','0','0','1496470419','1496470419','1','0','0','','http://www.nclmmryy.com/sygl/lxwm/2017-06-03/419.html','1','1','1','','联系我们','1496470404','','','<dd>南昌莱美美容医院</dd>\r\n<dd>地址：南昌市抚河南路261号</dd>\r\n<dd>网址：www.nclaimei.com</dd>\r\n<dd>微信：nclaimei</dd>\r\n<dd>电话：0791-86667777</dd>\r\n<dd>门诊时间：8：00-20：00</dd>','0','','','');");

@include("../../inc/footer.php");
?>