<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_new_data_1`;");
E_C("CREATE TABLE `lm_ecms_new_data_1` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `keyid` varchar(255) NOT NULL DEFAULT '',
  `dokey` tinyint(1) NOT NULL DEFAULT '0',
  `newstempid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `closepl` tinyint(1) NOT NULL DEFAULT '0',
  `haveaddfen` tinyint(1) NOT NULL DEFAULT '0',
  `infotags` varchar(80) NOT NULL DEFAULT '',
  `writer` varchar(30) NOT NULL DEFAULT '',
  `befrom` varchar(60) NOT NULL DEFAULT '',
  `newstext` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_new_data_1` values('395','187','','1','30','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('396','187','','1','30','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('397','189','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('398','189','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('399','189','','1','32','0','0','','','','<p>招聘保安一名</p>\r\n<p>招聘保洁一名</p>\r\n<p>招聘仓管一名</p>\r\n<p>招聘护士多名</p>\r\n<p>联系电话 : 079186667777</p>');");
E_D("replace into `lm_ecms_new_data_1` values('400','189','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('401','189','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('402','189','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('403','189','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('404','190','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('405','191','','1','0','0','0','','','','<p>&nbsp;<span style=\\\\\"color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">时下在专业整形医院进进出出的人越来越多，这说明整形美容业的发展越发蓬勃。但是需要警醒的是，有相当一部分人在非专业整形医院接受整形手术后出现后遗症，甚至有些在手术过程中就出现了生命危险。</span></p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　国家将整形机构分为三大级别，级别越高的单位就更称得上是专业整形医院。下文将阐述三级专业整形医院必须具有的五大资质。</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\"><strong style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box;\\\\\">　　何为专业整形医院?</strong></p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　专业整形医院是指由国家卫生部批准成立，有从事医疗卫生资格，以及施行外科手术资格的卫生部门。</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　<strong style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box;\\\\\">专业整形医院必须具备的资质：</strong></p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　1、资质荣誉：整形机构按卫生部标准(《美容医疗机构、医疗美容科(室)基本标准(试行)》卫医发2002103号)由高到低可分为：整形美容医院、门诊部、诊所(科室)。级别越高，标准越严格。</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　2、技术设备：专业整形医院要有&ldquo;呼吸机、心电监护仪、自动血压监测仪、电动吸引器、体外除颤器&rdquo;等基本设备，同时要&ldquo;具有与开展的诊疗科目相应的其他设备&rdquo;。设备齐全能给予整形美容手术及操作的安全保障和质量保证。 &gt;&gt;阴道松弛灭迹于专业整形医院</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　3、专家团队：确认相应专业整形医院的资质：《医师资格证、《执业医师证》和《医学美容主诊医生资格证》(外国医师来华短期行医还必须取得《外国医师短期行医许可证》)。有专业的固定技术人才梯队是正确的利器，具备从博士生导师、主任医生，到主治医生等各个层面的人才梯队。</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　4、综合环境：良好的整形医院环境与周边自然环境对人心情影响很大，而心情则直接影响术后恢复，所以，专业整形医院环境好，对康复效果的影响很明显。</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　5、成功案例：正规专业整形医院，有丰富临床经验的整形医生，都有自己比较典型、比较成功的手术案例，并有相当的知名度和美誉度。</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">&nbsp;</p>\r\n<p style=\\\\\"margin: 0px; padding: 0px; text-shadow: none; box-sizing: border-box; border: medium none; list-style-type: none; color: rgb(102, 102, 102); font-family: msyhl422459, 微软雅黑, Srial, Verdana, Geneva, sans-serif, tahoma, helvetica, sans-serif;\\\\\">　　南昌莱美美容医院是中国首家敢于承诺的美容医院，是江西具备专科医院资质的美容医院，我们以一等的技术，顶级的设备，专业的专家团队，良好的服务及术后保障!</p>');");
E_D("replace into `lm_ecms_new_data_1` values('406','191','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('407','191','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('408','191','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('409','191','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('410','191','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('411','191','','1','0','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('412','192','','1','31','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('413','192','','1','31','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('414','192','','1','31','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('415','192','','1','31','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('416','192','','1','31','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('417','192','','1','31','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('418','193','','1','30','0','0','','','','<p style=\\\\\"text-align: center;\\\\\">&nbsp;</p>\r\n<p style=\\\\\"text-align: center;\\\\\">&nbsp;</p>\r\n<p style=\\\\\"text-align: center;\\\\\">&nbsp;核心价值观：</p>\r\n<p style=\\\\\"text-align: center;\\\\\">诚实守信 勤奋创新</p>\r\n<p style=\\\\\"text-align: center;\\\\\">莱美使命：</p>\r\n<p style=\\\\\"text-align: center;\\\\\">推动中国医美行业的进步和发展</p>');");
E_D("replace into `lm_ecms_new_data_1` values('419','194','','1','30','0','0','','','','');");
E_D("replace into `lm_ecms_new_data_1` values('420','187','','1','0','0','0','','','','');");

@include("../../inc/footer.php");
?>