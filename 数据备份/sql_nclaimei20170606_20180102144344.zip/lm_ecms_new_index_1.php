<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_new_index`;");
E_C("CREATE TABLE `lm_ecms_new_index` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `checked` (`checked`),
  KEY `newstime` (`newstime`),
  KEY `truetime` (`truetime`,`id`),
  KEY `havehtml` (`classid`,`truetime`,`havehtml`,`checked`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=421 DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_new_index` values('395','187','1','1495691786','1495691835','1503036777','1');");
E_D("replace into `lm_ecms_new_index` values('396','187','1','1503037268','1495692022','1503037271','1');");
E_D("replace into `lm_ecms_new_index` values('397','189','1','1495851142','1495851161','1496543703','1');");
E_D("replace into `lm_ecms_new_index` values('398','189','1','1495851165','1495851175','1503035406','1');");
E_D("replace into `lm_ecms_new_index` values('399','189','1','1495851178','1495851189','1497950108','1');");
E_D("replace into `lm_ecms_new_index` values('400','189','1','1495851191','1495851196','1496543688','1');");
E_D("replace into `lm_ecms_new_index` values('401','189','1','1495851198','1495851203','1496543674','1');");
E_D("replace into `lm_ecms_new_index` values('402','189','1','1495851205','1495851215','1496543662','1');");
E_D("replace into `lm_ecms_new_index` values('403','189','1','1495851220','1495851223','1495851237','1');");
E_D("replace into `lm_ecms_new_index` values('404','190','1','1495851928','1495851955','1503795831','1');");
E_D("replace into `lm_ecms_new_index` values('405','191','1','1496216731','1496216507','1496644888','1');");
E_D("replace into `lm_ecms_new_index` values('406','191','1','1496216727','1496216517','1496216729','1');");
E_D("replace into `lm_ecms_new_index` values('407','191','1','1496216723','1496216526','1496216725','1');");
E_D("replace into `lm_ecms_new_index` values('408','191','1','1496216718','1496216531','1496216719','1');");
E_D("replace into `lm_ecms_new_index` values('409','191','1','1496216714','1496216538','1496216716','1');");
E_D("replace into `lm_ecms_new_index` values('410','191','1','1496216706','1496216543','1496216707','1');");
E_D("replace into `lm_ecms_new_index` values('411','191','1','1496216699','1496216548','1496216703','1');");
E_D("replace into `lm_ecms_new_index` values('412','192','1','1496469587','1496469596','1496643686','1');");
E_D("replace into `lm_ecms_new_index` values('413','192','1','1496469598','1496469602','1496643677','1');");
E_D("replace into `lm_ecms_new_index` values('414','192','1','1496469604','1496469614','1496643667','1');");
E_D("replace into `lm_ecms_new_index` values('415','192','1','1496469616','1496469621','1496643647','1');");
E_D("replace into `lm_ecms_new_index` values('416','192','1','1496469623','1496469626','1496643633','1');");
E_D("replace into `lm_ecms_new_index` values('417','192','1','1496469629','1496469632','1496643523','1');");
E_D("replace into `lm_ecms_new_index` values('418','193','1','1496470152','1496470224','1496709829','1');");
E_D("replace into `lm_ecms_new_index` values('419','194','1','1496470404','1496470419','1496470419','1');");
E_D("replace into `lm_ecms_new_index` values('420','187','1','1503036621','1503036637','1503036785','1');");

@include("../../inc/footer.php");
?>