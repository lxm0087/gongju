<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_zxmr`;");
E_C("CREATE TABLE `lm_ecms_zxmr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ttid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `onclick` int(10) unsigned NOT NULL DEFAULT '0',
  `plnum` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `totaldown` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `newspath` char(20) NOT NULL DEFAULT '',
  `filename` char(36) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL DEFAULT '',
  `firsttitle` tinyint(1) NOT NULL DEFAULT '0',
  `isgood` tinyint(1) NOT NULL DEFAULT '0',
  `ispic` tinyint(1) NOT NULL DEFAULT '0',
  `istop` tinyint(1) NOT NULL DEFAULT '0',
  `isqf` tinyint(1) NOT NULL DEFAULT '0',
  `ismember` tinyint(1) NOT NULL DEFAULT '0',
  `isurl` tinyint(1) NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userfen` smallint(5) unsigned NOT NULL DEFAULT '0',
  `titlefont` char(14) NOT NULL DEFAULT '',
  `titleurl` char(200) NOT NULL DEFAULT '',
  `stb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `fstb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `restb` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `keyboard` char(80) NOT NULL DEFAULT '',
  `title` char(100) NOT NULL DEFAULT '',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `titlepic` char(120) NOT NULL DEFAULT '',
  `ftitle` char(120) NOT NULL DEFAULT '',
  `smalltext` char(255) NOT NULL DEFAULT '',
  `diggtop` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `newstime` (`newstime`),
  KEY `ttid` (`ttid`),
  KEY `firsttitle` (`firsttitle`),
  KEY `isgood` (`isgood`),
  KEY `ispic` (`ispic`),
  KEY `useridis` (`userid`,`ismember`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_zxmr` values('122','85','0','0','0','0','2016-12-09','122','1','admin','0','0','1','0','0','0','1','1481250526','1481250764','1','0','0','','/s/BreastImplanta/index.html','1','1','1','','U弧立体美胸','1481250498','/d/file/xmzx/zxmr/2016-12-09/0fb26fe9ee5cff8ef74b2401d4c0464b.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('121','85','0','3','0','0','2016-12-02','121','1','admin','0','0','1','0','0','0','1','1480662116','1510537490','1','0','0','','/s/CarvedEyese/index.html','1','1','1','','韩式精雕双眼皮','1480662097','http://www.nclaimei.com/d/file/xmzx/zxmr/2017-11-13/c42faa8265dab9dc05ab52a85b1ece9d.jpg','','','0');");
E_D("replace into `lm_ecms_zxmr` values('120','29','0','1','0','0','2016-12-02','120','1','admin','0','0','1','0','0','0','1','1480662014','1510537585','1','0','0','','/s/HairRemoval/index.html','1','1','1','','冷肤脱毛','1480661990','http://www.nclaimei.com/d/file/xmzx/pfmr/2017-11-13/d28ede800be207c7f48cbb05d0a87961.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('132','26','0','0','0','0','2016-12-28','132','1','admin','0','0','1','0','0','0','1','1482915500','1510537681','1','0','0','','/s/DentalCorrection/index.html','1','1','1','','牙齿矫正','1482915365','http://www.nclaimei.com/d/file/xmzx/ycjz/2017-11-13/96b1f71362533118109bbc6c9902ff6a.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('129','27','0','0','0','0','2016-12-09','129','1','admin','0','0','1','0','0','0','1','1481251340','1510537634','1','0','0','','/s/FaceLiftNeedlea/index.html','1','1','1','','针功夫POTOX','1481251291','http://www.nclaimei.com/d/file/xmzx/vzx/2017-11-13/f3f2e7035f6b051c364236ec162489f4.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('128','27','0','0','0','0','2016-12-09','128','1','admin','0','0','1','0','0','0','1','1481251289','1510537651','1','0','0','','/s/FaceLiftNeedled/index.html','1','1','1','','针功夫微整形','1481251239','http://www.nclaimei.com/d/file/xmzx/vzx/2017-11-13/e28901cd628d07384d00b1d18d11be88.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('127','29','0','0','0','0','2016-12-09','127','1','admin','0','0','1','0','0','0','1','1481251224','1510537533','1','0','0','','/s/GlxfAcneTreatmenta/index.html','1','1','1','','光力雪肤祛痘','1481251182','http://www.nclaimei.com/d/file/xmzx/pfmr/2017-11-13/1dec469920e42bc16968ee28256d9514.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('126','29','0','0','0','0','2016-12-09','126','1','admin','0','0','1','0','0','0','1','1481251180','1510537550','1','0','0','','/s/OPTKingStyleb/index.html','1','1','1','','OPT王者风范','1481251126','http://www.nclaimei.com/d/file/xmzx/pfmr/2017-11-13/731fa3f325b79941ef1e3a6a59a92d5a.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('125','29','0','0','0','0','2016-12-09','125','1','admin','0','0','1','0','0','0','1','1481251124','1510537570','1','0','0','','/s/FreckleRemovingb/index.html','1','1','1','','祛斑净肤','1481251061','http://www.nclaimei.com/d/file/xmzx/pfmr/2017-11-13/053a3f59f3c2713d288d0c5588d20b27.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('124','85','0','0','0','0','2016-12-09','124','1','admin','0','0','1','0','0','0','1','1481250584','1510538099','1','0','0','','/s/SdlLiposuctiona/index.html','1','1','1','','水动力螺旋吸脂','1481250560','http://www.nclaimei.com/d/file/xmzx/zxmr/2016-12-09/a611d000900df4d00106fac8d6562a81.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('123','85','0','0','0','0','2016-12-09','123','1','admin','0','0','1','0','0','0','1','1481250558','1510537469','1','0','0','','/s/Rhinoplastyc/index.html','1','1','1','','多维美雕隆鼻','1481250528','http://www.nclaimei.com/d/file/xmzx/zxmr/2017-11-13/e2cf4817c86ffbe4af3656b4a1a22755.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('111','12','0','0','0','0','2016-11-30','111','1','admin','0','0','1','0','0','0','1','1480473794','1481249029','1','0','0','','/s/Hair/index.html','1','1','1','','FEU无痕植发','1480473730','/d/file/zxmr/mfzz/2016-11-30/cee87f707745d7d28eeb990cb462e0c3.png','适用人群','头发稀疏 | 地中海 | 严重脱发','0');");
E_D("replace into `lm_ecms_zxmr` values('112','12','0','0','0','0','2016-11-30','112','1','admin','0','0','1','0','0','0','0','1480473832','1481081020','1','0','0','','/zxmr/mfzz/2016-11-30/112.html','1','1','1','','眉毛种植','1480473796','/d/file/zxmr/mfzz/2016-11-30/4c135e23a587936b97b3ddb96913e740.png','适用人群','眉毛种植','0');");
E_D("replace into `lm_ecms_zxmr` values('113','12','0','0','0','0','2016-11-30','113','1','admin','0','0','1','0','0','0','0','1480473861','1481081029','1','0','0','','/zxmr/mfzz/2016-11-30/113.html','1','1','1','','睫毛种植','1480473834','/d/file/zxmr/mfzz/2016-11-30/64200abd9faa9747dd34ff8dddb2f3b4.png','适用人群','睫毛种植','0');");
E_D("replace into `lm_ecms_zxmr` values('114','12','0','0','0','0','2016-11-30','114','1','admin','0','0','1','0','0','0','0','1480473888','1481081042','1','0','0','','/zxmr/mfzz/2016-11-30/114.html','1','1','1','','胡须种植','1480473863','/d/file/zxmr/mfzz/2016-11-30/cc13cd80e3777abe93ca6a445add6542.png','适用人群','胡须种植','0');");
E_D("replace into `lm_ecms_zxmr` values('115','12','0','0','0','0','2016-11-30','115','1','admin','0','0','1','0','0','0','0','1480473918','1481081055','1','0','0','','/zxmr/mfzz/2016-11-30/115.html','1','1','1','','鬓角种植','1480473890','/d/file/zxmr/mfzz/2016-11-30/bdf11484d19ce728c7c7ebfb6f014829.png','适用人群','鬓角种植','0');");
E_D("replace into `lm_ecms_zxmr` values('116','12','0','0','0','0','2016-11-30','116','1','admin','0','0','1','0','0','0','0','1480473957','1481081065','1','0','0','','/zxmr/mfzz/2016-11-30/116.html','1','1','1','','发际线种植','1480473920','/d/file/zxmr/mfzz/2016-11-30/9e998cf2037f6e325f0f00b2eed3b29d.png','适用人群','发际线种植','0');");
E_D("replace into `lm_ecms_zxmr` values('117','12','0','0','0','0','2016-11-30','117','1','admin','0','0','1','0','0','0','0','1480473988','1481081077','1','0','0','','/zxmr/mfzz/2016-11-30/117.html','1','1','1','','美人尖种植','1480473959','/d/file/zxmr/mfzz/2016-11-30/add5b3b156975bbea4eb6b16c3e3cce1.png','适用人群','美人尖种植','0');");
E_D("replace into `lm_ecms_zxmr` values('118','12','0','0','0','0','2016-11-30','118','1','admin','0','0','1','0','0','0','0','1480474013','1481081085','1','0','0','','/zxmr/mfzz/2016-11-30/118.html','1','1','1','','私密种植','1480473990','/d/file/zxmr/mfzz/2016-11-30/fc642da1a4a9bf79f00d23e91e1a8956.png','适用人群','私密种植','0');");
E_D("replace into `lm_ecms_zxmr` values('130','27','0','0','0','0','2016-12-09','130','1','admin','0','0','1','0','0','0','1','1481251376','1510537617','1','0','0','','/s/BotoxKreotoxina/index.html','1','1','1','','POTOX抗衰老','1481251343','http://www.nclaimei.com/d/file/xmzx/vzx/2017-11-13/9e2299ea9145919848c56870243ad7c8.png','','','0');");
E_D("replace into `lm_ecms_zxmr` values('131','26','0','0','0','0','2016-12-09','131','1','admin','0','0','1','0','0','0','1','1481251511','1510537697','1','0','0','','/s/Teethas/index.html','1','1','1','','美容冠','1481251484','http://www.nclaimei.com/d/file/xmzx/ycjz/2017-11-13/0313d1906f01d8b5edc5fba6cd1e94cd.png','','','0');");

@include("../../inc/footer.php");
?>