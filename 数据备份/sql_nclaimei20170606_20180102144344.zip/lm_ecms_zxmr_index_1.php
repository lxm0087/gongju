<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_ecms_zxmr_index`;");
E_C("CREATE TABLE `lm_ecms_zxmr_index` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `checked` (`checked`),
  KEY `newstime` (`newstime`),
  KEY `truetime` (`truetime`,`id`),
  KEY `havehtml` (`classid`,`truetime`,`havehtml`,`checked`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8");
E_D("replace into `lm_ecms_zxmr_index` values('123','85','1','1481250528','1481250558','1510537469','1');");
E_D("replace into `lm_ecms_zxmr_index` values('131','26','1','1481251484','1481251511','1510537697','1');");
E_D("replace into `lm_ecms_zxmr_index` values('120','29','1','1480661990','1480662014','1510537585','1');");
E_D("replace into `lm_ecms_zxmr_index` values('122','85','1','1481250498','1481250526','1481250764','1');");
E_D("replace into `lm_ecms_zxmr_index` values('121','85','1','1480662097','1480662116','1510537490','1');");
E_D("replace into `lm_ecms_zxmr_index` values('124','85','1','1481250560','1481250584','1510538099','1');");
E_D("replace into `lm_ecms_zxmr_index` values('132','26','1','1482915365','1482915500','1510537681','1');");
E_D("replace into `lm_ecms_zxmr_index` values('130','27','1','1481251343','1481251376','1510537617','1');");
E_D("replace into `lm_ecms_zxmr_index` values('129','27','1','1481251291','1481251340','1510537634','1');");
E_D("replace into `lm_ecms_zxmr_index` values('128','27','1','1481251239','1481251289','1510537651','1');");
E_D("replace into `lm_ecms_zxmr_index` values('127','29','1','1481251182','1481251224','1510537533','1');");
E_D("replace into `lm_ecms_zxmr_index` values('126','29','1','1481251126','1481251180','1510537550','1');");
E_D("replace into `lm_ecms_zxmr_index` values('125','29','1','1481251061','1481251124','1510537570','1');");
E_D("replace into `lm_ecms_zxmr_index` values('111','12','1','1480473730','1480473794','1481249029','1');");
E_D("replace into `lm_ecms_zxmr_index` values('112','12','1','1480473796','1480473832','1481081020','1');");
E_D("replace into `lm_ecms_zxmr_index` values('113','12','1','1480473834','1480473861','1481081029','1');");
E_D("replace into `lm_ecms_zxmr_index` values('114','12','1','1480473863','1480473888','1481081042','1');");
E_D("replace into `lm_ecms_zxmr_index` values('115','12','1','1480473890','1480473918','1481081055','1');");
E_D("replace into `lm_ecms_zxmr_index` values('116','12','1','1480473920','1480473957','1481081065','1');");
E_D("replace into `lm_ecms_zxmr_index` values('117','12','1','1480473959','1480473988','1481081077','1');");
E_D("replace into `lm_ecms_zxmr_index` values('118','12','1','1480473990','1480474013','1481081085','1');");

@include("../../inc/footer.php");
?>