<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewsfeedbackclass`;");
E_C("CREATE TABLE `lm_enewsfeedbackclass` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `bname` varchar(60) NOT NULL DEFAULT '',
  `btemp` mediumtext NOT NULL,
  `bzs` varchar(255) NOT NULL DEFAULT '',
  `enter` text NOT NULL,
  `mustenter` text NOT NULL,
  `filef` varchar(255) NOT NULL DEFAULT '',
  `groupid` smallint(6) NOT NULL DEFAULT '0',
  `checkboxf` text NOT NULL,
  `usernames` text NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewsfeedbackclass` values('1','默认反馈分类','[!--cp.header--]<table width=100% align=center cellpadding=3 cellspacing=1 bgcolor=\\\\''#DBEAF5\\\\''><form name=\\\\''feedback\\\\'' method=\\\\''post\\\\'' enctype=\\\\''multipart/form-data\\\\'' action=\\\\''../../enews/index.php\\\\''><input name=\\\\''enews\\\\'' type=\\\\''hidden\\\\'' value=\\\\''AddFeedback\\\\''><tr><td width=\\\\''16%\\\\'' height=25 bgcolor=\\\\''ffffff\\\\''>信息标题</td><td bgcolor=\\\\''ffffff\\\\''><input name=\\\\''title\\\\'' type=\\\\''text\\\\'' value=\\\\''\\\\''>(*)</td></tr><tr><td width=\\\\''16%\\\\'' height=25 bgcolor=\\\\''ffffff\\\\''>性别</td><td bgcolor=\\\\''ffffff\\\\''><input name=\\\\\"sex[]\\\\\" type=\\\\\"checkbox\\\\\" value=\\\\\"\\\\\"></td></tr><tr><td width=\\\\''16%\\\\'' height=25 bgcolor=\\\\''ffffff\\\\''>出生年月</td><td bgcolor=\\\\''ffffff\\\\''><input name=\\\\''tr_birth\\\\'' type=\\\\''text\\\\'' value=\\\\''\\\\''></td></tr><tr><td width=\\\\''16%\\\\'' height=25 bgcolor=\\\\''ffffff\\\\''>手机号码</td><td bgcolor=\\\\''ffffff\\\\''><input name=\\\\''tr_tel\\\\'' type=\\\\''text\\\\'' value=\\\\''\\\\''></td></tr><tr><td width=\\\\''16%\\\\'' height=25 bgcolor=\\\\''ffffff\\\\''>职业</td><td bgcolor=\\\\''ffffff\\\\''><input name=\\\\''tr_job\\\\'' type=\\\\''text\\\\'' value=\\\\''\\\\''></td></tr><tr><td width=\\\\''16%\\\\'' height=25 bgcolor=\\\\''ffffff\\\\''>整形经历</td><td bgcolor=\\\\''ffffff\\\\''><input name=\\\\\"zxjl[]\\\\\" type=\\\\\"checkbox\\\\\" value=\\\\\"\\\\\"></td></tr><tr><td width=\\\\''16%\\\\'' height=25 bgcolor=\\\\''ffffff\\\\''>问题</td><td bgcolor=\\\\''ffffff\\\\''><input name=\\\\\"tr_wenti[]\\\\\" type=\\\\\"checkbox\\\\\" value=\\\\\"\\\\\"></td></tr><tr><td bgcolor=\\\\''ffffff\\\\''></td><td bgcolor=\\\\''ffffff\\\\''><input type=\\\\''submit\\\\'' name=\\\\''submit\\\\'' value=\\\\''提交\\\\''></td></tr></form></table>[!--cp.footer--]','','信息标题<!--field--->title<!--record-->性别<!--field--->hf_sex<!--record-->出生年月<!--field--->tr_birth<!--record-->手机号码<!--field--->tr_tel<!--record-->职业<!--field--->tr_job<!--record-->整形经历<!--field--->hf_zxjl<!--record-->问题<!--field--->tr_wenti<!--record-->',',title,',',','0',',hf_zxjl,tr_wenti,hf_sex,','');");

@include("../../inc/footer.php");
?>