<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewsfeedbackf`;");
E_C("CREATE TABLE `lm_enewsfeedbackf` (
  `fid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `f` varchar(30) NOT NULL DEFAULT '',
  `fname` varchar(30) NOT NULL DEFAULT '',
  `fform` varchar(20) NOT NULL DEFAULT '',
  `fzs` varchar(255) NOT NULL DEFAULT '',
  `myorder` smallint(6) NOT NULL DEFAULT '0',
  `ftype` varchar(30) NOT NULL DEFAULT '',
  `flen` varchar(20) NOT NULL DEFAULT '',
  `fformsize` varchar(12) NOT NULL DEFAULT '',
  `fvalue` text NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewsfeedbackf` values('1','title','姓名','text','','0','VARCHAR','120','','');");
E_D("replace into `lm_enewsfeedbackf` values('13','tr_job','职业','text','','4','VARCHAR','30','','');");
E_D("replace into `lm_enewsfeedbackf` values('12','tr_tel','手机号码','text','','3','VARCHAR','20','','');");
E_D("replace into `lm_enewsfeedbackf` values('14','hf_zxjl','整形经历','checkbox','','5','VARCHAR','30','','');");
E_D("replace into `lm_enewsfeedbackf` values('15','tr_wenti','问题','checkbox','','6','VARCHAR','30','','');");
E_D("replace into `lm_enewsfeedbackf` values('10','hf_sex','性别','checkbox','','1','VARCHAR','15','','');");
E_D("replace into `lm_enewsfeedbackf` values('11','tr_birth','出生年月','text','','2','VARCHAR','30','','');");

@include("../../inc/footer.php");
?>