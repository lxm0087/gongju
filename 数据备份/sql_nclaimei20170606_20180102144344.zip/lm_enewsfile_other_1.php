<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewsfile_other`;");
E_C("CREATE TABLE `lm_enewsfile_other` (
  `fileid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pubid` tinyint(1) NOT NULL DEFAULT '0',
  `filename` char(60) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `path` char(20) NOT NULL DEFAULT '',
  `adduser` char(30) NOT NULL DEFAULT '',
  `filetime` int(10) unsigned NOT NULL DEFAULT '0',
  `classid` tinyint(1) NOT NULL DEFAULT '0',
  `no` char(60) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `onclick` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `cjid` int(10) unsigned NOT NULL DEFAULT '0',
  `fpath` tinyint(1) NOT NULL DEFAULT '0',
  `modtype` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fileid`),
  KEY `id` (`id`),
  KEY `type` (`type`),
  KEY `modtype` (`modtype`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewsfile_other` values('56','0','835cfeb3c0db21f58f19eaa134545094.png','173470','2017-02-07','admin','1486438525','0','indexa_03.png','1','0','87','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('2','0','981a19674112f5050cc0a040bc145799.jpg','20036','2016-11-18','admin','1479435523','0','menuimg1.jpg','1','0','1','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('3','0','f139b4595ba8e54f40077a476f8a5e81.jpg','11397','2016-11-18','admin','1479435535','0','menuimg2.jpg','1','0','1','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('4','0','d29ed5a2a18fbf4759de0aaedf496695.jpg','25783','2016-11-21','admin','1479697770','0','menuimg12.jpg','1','0','9','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('5','0','ef8a90adb5d482363b598ab44a47fa9e.jpg','15578','2016-11-21','admin','1479697820','0','menuimg15.jpg','1','0','11','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('6','0','4d16befabb68b0ce46552655d7744b30.jpg','11570','2016-11-21','admin','1479711643','0','menuimg3.jpg','1','0','59','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('7','0','b6719c94667be63809725727737914a9.jpg','19020','2016-11-21','admin','1479711949','0','menuimg5.jpg','1','0','60','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('8','0','494b05b74870d07ca2ef6189174bd74a.jpg','12109','2016-11-21','admin','1479712074','0','menuimg6.jpg','1','0','61','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('9','0','a5a01975a221ed3af119b719b212de73.jpg','20650','2016-11-21','admin','1479712129','0','menuimg7.jpg','1','0','62','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('10','0','20e981a1d9155e7a5a10e1c7db5e8efd.jpg','19550','2016-11-21','admin','1479712243','0','menuimg8.jpg','1','0','63','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('11','0','c91570dc202d5e043b2199b4299f8bad.jpg','23455','2016-11-21','admin','1479712280','0','menuimg9.jpg','1','0','64','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('12','0','7651349af99a692555a058bc694a039e.jpg','18323','2016-11-21','admin','1479712404','0','menuimg10.jpg','1','0','65','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('13','0','8c8716342667ea0871d45bfe82dbce8c.jpg','26299','2016-11-21','admin','1479712496','0','menuimg14.jpg','1','0','66','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('58','0','21c2a6d13b332378f3eeb1eef797156a.png','166721','2017-02-23','admin','1487819567','0','8118fc8da94e4bfb802771eca12c9ee2.png','1','0','98','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('59','0','a1d5b0251358719a33192725288ac091.png','198322','2017-02-23','admin','1487819620','0','c77a2627f3d5bdd2e9987f0d72ef65ca.png','1','0','97','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('57','0','14a3052fcf21f32fee1be1ae5ba946af.png','186837','2017-02-23','admin','1487819321','0','3d7aa402948aa197f838386de1870bc5.png','1','0','99','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('20','0','7c0af99724df5fcfd0bf40748fafc3d0.png','169817','2016-11-22','admin','1479788794','0','眼部整形1_03.png','1','0','59','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('24','0','fdf57b5b8ad52ec6d8cf94736dd826f3.png','169817','2016-11-23','admin','1479875909','0','眼部整形1_03.png','1','0','39','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('25','0','ec7800d635cfc3c20c0389b0653b307d.png','192623','2016-11-23','admin','1479881086','0','眼部整形2_03.png','1','0','40','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('26','0','de84afede01699ee951efecbd43b5b39.png','170416','2016-11-23','admin','1479881103','0','眼部整形3_03.png','1','0','41','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('27','0','3d7aa402948aa197f838386de1870bc5.png','186837','2016-11-23','admin','1479881119','0','眼部整形4_03.png','1','0','42','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('35','0','d8ce25af7fffb98922fda165ed9e074d.png','134461','2016-11-24','admin','1479974283','0','鼻部2_03.png','1','0','49','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('29','0','c9d84978d4818b2bddffae70d2b7e056.png','211575','2016-11-24','admin','1479970060','0','胸部整形1_03.png','1','0','44','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('30','0','c77a2627f3d5bdd2e9987f0d72ef65ca.png','198322','2016-11-24','admin','1479970433','0','胸部整形2_05.png','1','0','45','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('31','0','c72ec76e6173b70827e5487f66e22f76.png','132598','2016-11-24','admin','1479970470','0','胸部整形3_09.png','1','0','46','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('32','0','bc22d46de0784657d1b11c40bfa5372f.png','162134','2016-11-24','admin','1479970496','0','胸部整形5_09.png','1','0','47','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('33','0','e87cdaa7d5bbe8dead0b1dc44e13c9c3.png','65154','2016-11-24','admin','1479970569','0','胸部整形6_09.png','1','0','48','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('34','0','8118fc8da94e4bfb802771eca12c9ee2.png','166721','2016-11-24','admin','1479974264','0','鼻部1_03.png','1','0','43','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('36','0','d5f3b553e07eaa110d665ccc668bd7ae.png','89610','2016-11-24','admin','1479975556','0','形体塑雕1_03.png','1','0','50','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('37','0','6a49ce2ba15cc8b6ce9854a510ab22e2.png','111334','2016-11-24','admin','1479975616','0','形体塑雕2_03.png','1','0','51','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('38','0','294bbea2616e450e1565acee9f9339f6.png','128793','2016-11-24','admin','1479978592','0','微整形1_03.png','1','0','52','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('39','0','0651ec02e7c50ef6a8b65016288153b1.png','106230','2016-11-24','admin','1479978639','0','微整形2_03.png','1','0','53','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('40','0','1f1b9ec2137df8b936ccad9ae556f2db.png','124510','2016-11-24','admin','1479978695','0','微整形3_03.png','1','0','54','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('41','0','1e0458b0b6561fb91b7a6dba879af549.png','149444','2016-11-24','admin','1479978754','0','微整形4_03.png','1','0','55','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('42','0','07b57382a6ff478daeef7742ab292bf1.png','108575','2016-11-25','admin','1480062289','0','皮肤美容1_03.png','1','0','56','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('43','0','8a38430eb2731a2829fac0238a857bf6.png','84236','2016-11-25','admin','1480062340','0','皮肤美容2_03.png','1','0','57','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('44','0','e6614b4f53da124bcf5ffdcbaa3a3b7b.png','99474','2016-11-25','admin','1480062384','0','皮肤美容3_03.png','1','0','58','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('45','0','3e1078ae3656b8e586f95d8e2765d155.png','127856','2016-11-25','admin','1480062497','0','皮肤美容4_03.png','1','0','59','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('46','0','42a0646f200c266e1162f8bfc8dc45e5.png','65284','2016-11-25','admin','1480062555','0','皮肤美容5_03.png','1','0','60','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('47','0','e4a07444e88c61b0bf70bc17913bb02f.png','178131','2016-11-25','admin','1480062604','0','皮肤美容6_03.png','1','0','61','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('48','0','1272f91726635de063d5417372646b68.png','126863','2016-11-30','admin','1480474119','0','面部轮廓1_03.png','1','0','62','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('49','0','d9650b8cfa53c7386d9787cc6a32e4e2.png','137325','2016-11-30','admin','1480474175','0','面部轮廓2_03.png','1','0','63','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('50','0','9e7a24af92a6c3c0b4d9128a2bb1f552.png','193493','2016-11-30','admin','1480474229','0','面部轮廓3_03.png','1','0','64','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('51','0','33af32dbe68839e66d034f3d9854829a.png','162256','2016-12-01','admin','1480557841','0','口腔美容1_03.png','1','0','65','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('52','0','ad9109c4137edb71a1ef617d66153bdf.png','174125','2016-12-01','admin','1480557894','0','口腔美容2_03.png','1','0','66','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('53','0','ad8114d63d89841dc8a47be2f4cc29dc.png','172952','2016-12-01','admin','1480557945','0','口腔美容3_03.png','1','0','67','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('54','0','bee207e42459584b82714785b66406e4.png','217141','2016-12-01','admin','1480557983','0','口腔美容4_03.png','1','0','68','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('55','0','28e8e6f0f8fa424d5370f9fb59ef22c1.png','184682','2016-12-01','admin','1480558028','0','口腔美容5_03.png','1','0','69','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('60','0','6959173cdcadf4e627a52ab71cd422bd.png','126863','2017-02-23','admin','1487819659','0','1272f91726635de063d5417372646b68.png','1','0','96','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('61','0','5c81fd97c8538e7e52a2ca8d990e940d.png','89610','2017-02-23','admin','1487819692','0','d5f3b553e07eaa110d665ccc668bd7ae.png','1','0','95','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('62','0','be20eaddf7ae603d4d4a979360a69aba.png','127856','2017-02-23','admin','1487819736','0','3e1078ae3656b8e586f95d8e2765d155.png','1','0','94','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('63','0','c99a7f652d07975b8cb66ad2175f5a7b.png','128793','2017-02-23','admin','1487819789','0','294bbea2616e450e1565acee9f9339f6.png','1','0','93','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('64','0','8fe15df96dc88ac5948677cf786a3c14.png','91725','2017-02-23','admin','1487819819','0','accf191f74d4deda6844ea9eae77cd3d.png','1','0','91','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('65','0','e7c5f63ad1110ded0f47912f2989150d.jpg','97012','2017-02-24','admin','1487917631','0','231X395slsp.jpg','1','0','88','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('66','0','52ee51a176a072b42ceaeffc819c4d9a.jpg','89811','2017-02-24','admin','1487917656','0','231X395yc.jpg','1','0','89','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('67','0','f65f242c04dd5b1c293578175fc8a129.jpg','80733','2017-02-24','admin','1487917673','0','231X395yxjz.jpg','1','0','90','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('68','0','08be7744fd5c4e8dbacd1d3003701fc3.png','178131','2017-02-28','admin','1488241681','0','e4a07444e88c61b0bf70bc17913bb02f.png','1','0','100','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('69','0','f151bc4694faa3f9340064c314c40e03.png','65284','2017-02-28','admin','1488241708','0','42a0646f200c266e1162f8bfc8dc45e5.png','1','0','101','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('70','0','6e0b6f42bc5e2271af4b4039bc99edf2.png','127856','2017-02-28','admin','1488241727','0','3e1078ae3656b8e586f95d8e2765d155.png','1','0','102','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('71','0','c3a6dc357ece32232a72c34d82df69c6.png','99474','2017-02-28','admin','1488241745','0','e6614b4f53da124bcf5ffdcbaa3a3b7b.png','1','0','103','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('72','0','a3cc52213e2f9e0036618831efd957a7.png','84236','2017-02-28','admin','1488241772','0','8a38430eb2731a2829fac0238a857bf6.png','1','0','104','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('73','0','d78005e514773de33d1ee45e0ed0d4be.png','108575','2017-02-28','admin','1488241790','0','07b57382a6ff478daeef7742ab292bf1.png','1','0','105','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('74','0','30fea76abe0951c096c71c0a62d54e91.png','111334','2017-02-28','admin','1488241831','0','6a49ce2ba15cc8b6ce9854a510ab22e2.png','1','0','106','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('75','0','4dc55408f6b8318f37a0c1df8de0c529.png','149444','2017-02-28','admin','1488241851','0','1e0458b0b6561fb91b7a6dba879af549.png','1','0','107','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('76','0','69fe8c6441ab126f5c9e7c47d6ac148e.png','124510','2017-02-28','admin','1488241873','0','1f1b9ec2137df8b936ccad9ae556f2db.png','1','0','108','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('77','0','6c98739c9c865c99023410911c22cf63.png','106230','2017-02-28','admin','1488241890','0','0651ec02e7c50ef6a8b65016288153b1.png','1','0','109','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('78','0','5682d3090e5feb61f8a1ec80de30c4f7.png','128793','2017-02-28','admin','1488241917','0','294bbea2616e450e1565acee9f9339f6.png','1','0','110','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('79','0','072186755e6f1b4fa139a9d71b35740f.png','184682','2017-02-28','admin','1488241943','0','28e8e6f0f8fa424d5370f9fb59ef22c1.png','1','0','111','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('80','0','f3196d7e32be4b794c85762d0718e225.png','217141','2017-02-28','admin','1488241960','0','bee207e42459584b82714785b66406e4.png','1','0','112','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('81','0','d28b5d1ec4d260855458d2337cb9f735.png','172952','2017-02-28','admin','1488241977','0','ad8114d63d89841dc8a47be2f4cc29dc.png','1','0','113','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('82','0','96a17cab9e3ad877f1565429c48b3af1.png','174125','2017-02-28','admin','1488241995','0','ad9109c4137edb71a1ef617d66153bdf.png','1','0','114','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('83','0','c67d2afd5795178b5ad43368d3762e09.png','162256','2017-02-28','admin','1488242024','0','33af32dbe68839e66d034f3d9854829a.png','1','0','115','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('88','0','b1c7e81272928a31a94b43d8aa3f22bd.jpg','35980','2017-05-31','admin','1496216426','0','pic2.jpg','1','0','191','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('93','0','ec89d2b5b5aea271e78130ff5db5dbad.jpg','218750','2017-06-07','admin','1496814576','0','640309zj.jpg','1','0','177','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('89','0','a297cd5b484cbab62f0e360ec20d2f18.jpg','35552','2017-06-03','admin','1496469820','0','pic3.jpg','1','0','192','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('90','0','f90b2788053fa67f27789b72e20b4ee0.jpg','17569','2017-06-03','admin','1496469936','0','pic4.jpg','1','0','193','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('91','0','b424c3454c595c043f9d750f02b6ba7d.jpg','47922','2017-06-03','admin','1496469967','0','pic5.jpg','1','0','194','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('96','0','8ec9303e34aa4b8ebe0c95853ff4d2be.jpg','78214','2017-08-18','admin','1503036470','0','laimei.jpg','1','0','190','0','0','1');");
E_D("replace into `lm_enewsfile_other` values('95','0','8bcb45db9df6382be1d5699ec2a75fe9.png','125197','2017-06-14','admin','1497427961','0','pic18.png','1','0','202','0','0','1');");

@include("../../inc/footer.php");
?>