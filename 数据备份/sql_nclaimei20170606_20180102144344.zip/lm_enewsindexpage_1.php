<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewsindexpage`;");
E_C("CREATE TABLE `lm_enewsindexpage` (
  `tempid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `tempname` varchar(30) NOT NULL DEFAULT '',
  `temptext` mediumtext NOT NULL,
  PRIMARY KEY (`tempid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewsindexpage` values('1','20170828','<!DOCTYPE html PUBLIC \\\\\"-//W3C//DTD XHTML 1.0 Transitional//EN\\\\\" \\\\\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\\\\\">\r\n<html xmlns=\\\\\"http://www.w3.org/1999/xhtml\\\\\">\r\n<head>\r\n<meta http-equiv=\\\\\"Content-Type\\\\\" content=\\\\\"text/html; charset=utf-8\\\\\" />\r\n<title>南昌莱美美容医院</title>\r\n<meta name=\\\\\"keywords\\\\\" content=\\\\\"keywords\\\\\" />\r\n<meta name=\\\\\"description\\\\\" content=\\\\\"description\\\\\" />\r\n<meta http-equiv=\\\\\"refresh\\\\\" content=\\\\\"0.1;url=http://www.nclmmryy.com/\\\\\">\r\n</head>\r\n<body></body>\r\n</html>');");

@include("../../inc/footer.php");
?>