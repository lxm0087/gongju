<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewspageclass`;");
E_C("CREATE TABLE `lm_enewspageclass` (
  `classid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `classname` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewspageclass` values('1','www.nclaimei.net');");
E_D("replace into `lm_enewspageclass` values('2','www.nclaimei.com');");
E_D("replace into `lm_enewspageclass` values('3','m.nclaimei.com');");
E_D("replace into `lm_enewspageclass` values('4','m.nclaimei.net');");

@include("../../inc/footer.php");
?>