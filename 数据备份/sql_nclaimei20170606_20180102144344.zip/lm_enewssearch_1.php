<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewssearch`;");
E_C("CREATE TABLE `lm_enewssearch` (
  `searchid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `keyboard` varchar(255) NOT NULL DEFAULT '',
  `searchtime` int(10) unsigned NOT NULL DEFAULT '0',
  `searchclass` varchar(255) NOT NULL DEFAULT '',
  `result_num` int(10) unsigned NOT NULL DEFAULT '0',
  `searchip` varchar(20) NOT NULL DEFAULT '',
  `classid` varchar(255) NOT NULL DEFAULT '',
  `onclick` int(10) unsigned NOT NULL DEFAULT '0',
  `orderby` varchar(30) NOT NULL DEFAULT '0',
  `myorder` tinyint(1) NOT NULL DEFAULT '0',
  `checkpass` varchar(32) NOT NULL DEFAULT '',
  `tbname` varchar(60) NOT NULL DEFAULT '',
  `tempid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `iskey` tinyint(1) NOT NULL DEFAULT '0',
  `andsql` text NOT NULL,
  `trueclassid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`searchid`),
  KEY `checkpass` (`checkpass`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewssearch` values('1','双眼皮','1489209225','title','6','218.64.68.176','','35','newstime','0','fd5264fd8bead86fb291ccd174100f40','news','1','0',' and ((title LIKE ''%双眼皮%''))','0');");
E_D("replace into `lm_enewssearch` values('2','植发','1495788210','title','4','218.64.68.176','','2','newstime','0','928e21ab240299078386e828b4e6d368','news','1','0',' and ((title LIKE ''%植发%''))','0');");
E_D("replace into `lm_enewssearch` values('3','小腿','1483502137','title','1','59.53.29.187','','1','newstime','0','66807a9b47533092ab64219ab85af281','news','1','0',' and ((title LIKE ''%小腿%''))','0');");
E_D("replace into `lm_enewssearch` values('4','眼部','1496761872','title','4','218.64.68.176','','2','newstime','0','4574657e4bb26ed1d49128a85fb88a65','news','1','0',' and ((title LIKE ''%眼部%''))','0');");
E_D("replace into `lm_enewssearch` values('5','处女膜','1483852258','title','1','220.114.232.72','','1','newstime','0','a5aaa4d53149891bb0340eead7edce50','news','1','0',' and ((title LIKE ''%处女膜%''))','0');");
E_D("replace into `lm_enewssearch` values('6','BOTOX','1484372989','title','2','218.64.68.176','','1','newstime','0','c7bfcb5429adf35df618bbc7a93c3ec0','news','1','0',' and ((title LIKE ''%BOTOX%''))','0');");
E_D("replace into `lm_enewssearch` values('7','祛斑','1491890614','title','1','218.64.68.176','','4','newstime','0','58b8438e7b2d2b44ca8c31865c26082c','news','1','0',' and ((title LIKE ''%祛斑%''))','0');");
E_D("replace into `lm_enewssearch` values('8','超声刀','1484454850','title','4','111.221.157.83','','1','newstime','0','4bec446436340926f3c2aad820d74124','news','1','0',' and ((title LIKE ''%超声刀%''))','0');");
E_D("replace into `lm_enewssearch` values('9','玻尿酸','1484548142','title','4','218.64.68.176','','1','newstime','0','b0db28646cf8f506c489e79a96b17917','news','1','0',' and ((title LIKE ''%玻尿酸%''))','0');");
E_D("replace into `lm_enewssearch` values('10','瘦脸','1485069642','title','1','171.35.166.159','','1','newstime','0','1d77891a12e952421f7b93a15e8a68d4','news','1','0',' and ((title LIKE ''%瘦脸%''))','0');");
E_D("replace into `lm_enewssearch` values('11','眼袋','1486370200','title','2','106.6.166.141','','1','newstime','0','5ca42719a06323e529042e277274370e','news','1','0',' and ((title LIKE ''%眼袋%''))','0');");
E_D("replace into `lm_enewssearch` values('12','皮秒','1490333859','title','3','218.64.68.176','','5','newstime','0','eff9414fc8fff388d241c620849adaa0','news','1','0',' and ((title LIKE ''%皮秒%''))','0');");
E_D("replace into `lm_enewssearch` values('13','腋毛','1486540050','title','1','218.64.68.176','','2','newstime','0','4ce0245073cd5f16a4ded71c0bf32e21','news','1','0',' and ((title LIKE ''%腋毛%''))','0');");
E_D("replace into `lm_enewssearch` values('14','祛痘','1486865573','title','2','218.64.68.176','','4','newstime','0','0c8f0cecb1f63da5c0e49029b4d5ef6c','news','1','0',' and ((title LIKE ''%祛痘%''))','0');");
E_D("replace into `lm_enewssearch` values('15','洁牙','1486868349','title','2','218.64.68.176','','2','newstime','0','734589d5c4dc702940628b84bafcd51a','news','1','0',' and ((title LIKE ''%洁牙%''))','0');");
E_D("replace into `lm_enewssearch` values('16','脱毛','1492420930','title','7','218.64.68.176','','5','newstime','0','fdb88acc0fcf85d43450eb03f49ffdb4','news','1','0',' and ((title LIKE ''%脱毛%''))','0');");
E_D("replace into `lm_enewssearch` values('17','私密整形','1486869423','title','1','218.64.68.176','','1','newstime','0','f4a344f013082450ff42805d8295045f','news','1','0',' and ((title LIKE ''%私密整形%''))','0');");
E_D("replace into `lm_enewssearch` values('18','私密','1486890726','title','3','218.64.68.176','','1','newstime','0','52bd017519de8f6aa46c4211f300732d','news','1','0',' and ((title LIKE ''%私密%''))','0');");
E_D("replace into `lm_enewssearch` values('19','莱美','1487552707','title','9','218.64.68.176','','1','newstime','0','4f1d0dca08874aaeb5f2515a4522efb7','news','1','0',' and ((title LIKE ''%莱美%''))','0');");
E_D("replace into `lm_enewssearch` values('20','微整形','1487658409','title','5','218.64.68.176','','1','newstime','0','a73e12347f1c6984d2cc437f786a873e','news','1','0',' and ((title LIKE ''%微整形%''))','0');");
E_D("replace into `lm_enewssearch` values('21','法令','1487995419','title','2','117.42.196.213','','1','newstime','0','842095abb3dd22806d31a274ec74ffd9','news','1','0',' and ((title LIKE ''%法令%''))','0');");
E_D("replace into `lm_enewssearch` values('22','皮肤','1488252434','title','3','218.64.68.176','','1','newstime','0','0a5dd06469b72de71e40235f89212fc1','news','1','0',' and ((title LIKE ''%皮肤%''))','0');");
E_D("replace into `lm_enewssearch` values('23','私密超声刀','1490334202','title','1','218.64.68.176','','4','newstime','0','59cc9f987909e2f83bbee982e77549d8','news','1','0',' and ((title LIKE ''%私密超声刀%''))','0');");
E_D("replace into `lm_enewssearch` values('24','除皱','1490232898','title','2','218.64.68.176','','1','newstime','0','82f5586ba8458656139ee72e38929f36','news','1','0',' and ((title LIKE ''%除皱%''))','0');");
E_D("replace into `lm_enewssearch` values('25','减肥','1490233871','title','2','218.64.68.176','','1','newstime','0','b290f298b78f76ac46d0b2ce5b722944','news','1','0',' and ((title LIKE ''%减肥%''))','0');");
E_D("replace into `lm_enewssearch` values('26','美容文化节','1491011069','title','2','218.64.68.176','','1','newstime','0','dca4912be43ec0a4bf45c4cf82c9fda3','news','1','0',' and ((title LIKE ''%美容文化节%''))','0');");
E_D("replace into `lm_enewssearch` values('27','脸','1495035960','title','4','118.212.158.78','','1','newstime','0','461938982819366d4beeff2f0834faa8','news','1','0',' and ((title LIKE ''%脸%''))','0');");
E_D("replace into `lm_enewssearch` values('28','王者风范','1500561635','title','1','117.44.163.127','','2','newstime','0','dfb834db8630f2a54d2404c11a102211','news','1','0',' and ((title LIKE ''%王者风范%''))','0');");
E_D("replace into `lm_enewssearch` values('29','瘦脸针','1496198222','title','1','218.64.68.176','','1','newstime','0','f8bacf2d56007276846c9a5b3c73b5ed','news','1','0',' and ((title LIKE ''%瘦脸针%''))','0');");
E_D("replace into `lm_enewssearch` values('30','开眼角','1498612121','title','1','59.53.16.28','','1','newstime','0','f965249bd1007794097bfb9d8f6cc067','news','1','0',' and ((title LIKE ''%开眼角%''))','0');");
E_D("replace into `lm_enewssearch` values('31','王者','1500561584','title','1','220.175.70.140','','1','newstime','0','f6720bdad610f276322bba6609c37f81','news','1','0',' and ((title LIKE ''%王者%''))','0');");
E_D("replace into `lm_enewssearch` values('32','胸','1502692139','title','11','106.6.163.76','','1','newstime','0','4735d271e3a9172e53c4ed7887ba95cd','news','1','0',' and ((title LIKE ''%胸%''))','0');");
E_D("replace into `lm_enewssearch` values('33','无针水光','1509428932','title','1','59.53.27.192','','1','newstime','0','498c3459efbba8c43970455cd84f5ed6','news','1','0',' and ((title LIKE ''%无针水光%''))','0');");
E_D("replace into `lm_enewssearch` values('34','毛孔','1510126392','title','1','182.84.195.10','','1','newstime','0','aa20447375c923266c8f189503cff9f2','news','1','0',' and ((title LIKE ''%毛孔%''))','0');");

@include("../../inc/footer.php");
?>