<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewssearchtemp`;");
E_C("CREATE TABLE `lm_enewssearchtemp` (
  `tempid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `tempname` varchar(60) NOT NULL DEFAULT '',
  `temptext` mediumtext NOT NULL,
  `subnews` smallint(6) NOT NULL DEFAULT '0',
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  `listvar` text NOT NULL,
  `rownum` smallint(6) NOT NULL DEFAULT '0',
  `modid` smallint(6) NOT NULL DEFAULT '0',
  `showdate` varchar(50) NOT NULL DEFAULT '',
  `subtitle` smallint(6) NOT NULL DEFAULT '0',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `docode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tempid`),
  KEY `classid` (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewssearchtemp` values('1','默认搜索模板','<!doctype html>\r\n<html>\r\n<head>\r\n<meta name=\\\\\"renderer\\\\\" content=\\\\\"webkit\\\\\"/>\r\n<meta http-equiv=\\\\\"X-UA-Comabsolutetible\\\\\" content=\\\\\"IE=Edge,chrome=1\\\\\" />\r\n<meta name=\\\\\"format-detection\\\\\" content=\\\\\"telephone=on\\\\\"/>\r\n<meta http-equiv=\\\\\"Content-Type\\\\\" content=\\\\\"text/html; charset=utf-8\\\\\" />\r\n<title>[!--pagetitle--]_南昌莱美美容医院</title>\r\n<link href=\\\\\"[!--news.url--]skin/laimei2017/css/reset.css\\\\\" rel=\\\\\"stylesheet\\\\\"/>\r\n<script src=\\\\\"[!--news.url--]skin/laimei2017/js/jquery-1.9.1.min.js\\\\\"></script>\r\n<script src=\\\\\"[!--news.url--]skin/laimei2017/js/jquery.superslide.2.1.1.source.js\\\\\"></script>\r\n<script src=\\\\\"[!--news.url--]skin/laimei2017/js/indexapp.js\\\\\"></script>\r\n<link href=\\\\\"[!--news.url--]search/css/style.css\\\\\" rel=\\\\\"stylesheet\\\\\"/>\r\n</head>\r\n<body>\r\n[!--temp.header--]\r\n<div class=\\\\\"SearchWrap pubW center\\\\\">\r\n	<div class=\\\\\"SearchNav\\\\\">\r\n		<a href=\\\\\"[!--news.url--]\\\\\">首页</a>>搜索结果<span>系统搜索到约有:<strong>[!--ecms.num--]</strong>项符合<strong>[!--keyboard--]</strong>的查询结果</span>\r\n	</div>\r\n	<div class=\\\\\"SearchStage pubW center\\\\\">\r\n		<ul class=\\\\\"square\\\\\">\r\n			[!--empirenews.listtemp--]<!--list.var1-->[!--empirenews.listtemp--]\r\n		</ul>\r\n	</div>\r\n	[!--show.page--]\r\n</div>\r\n<!--footer--> \r\n[!--temp.footer--]\r\n<!--footer  结束-->','180','1','<li><a href=\\\\\"[!--titleurl--]\\\\\">[!--title--]</a><span>[!--newstime--]</span></li>','1','1','Y-m-d','0','0','0');");
E_D("replace into `lm_enewssearchtemp` values('2','站点二搜索模板','<!doctype html>\r\n<html>\r\n<head>\r\n	<link type=\\\\\"text/css\\\\\" rel=\\\\\"shortout icon\\\\\" href=\\\\\"[!--news.url--]skin/laimei2017/images/favicon.ico\\\\\" />\r\n	<meta http-equiv=\\\\\"Content-Type\\\\\" content=\\\\\"text/html; charset=utf-8\\\\\" />\r\n	<title>[!--pagetitle--]-南昌莱美美容整形医院</title>\r\n	<meta name=\\\\\"keywords\\\\\" content=\\\\\"[!--pagekeywords--]\\\\\" />\r\n	<meta name=\\\\\"description\\\\\" content=\\\\\"[!--pagedescription--]\\\\\" />\r\n	<link type=\\\\\"text/css\\\\\" rel=\\\\\"stylesheet\\\\\" href=\\\\\"[!--news.url--]skin/WwwNetCom/css/base.css\\\\\" />\r\n	<script type=\\\\\"text/javascript\\\\\" src=\\\\\"[!--news.url--]skin/WwwNetCom/js/jquery-1.8.2.js\\\\\"></script>\r\n	<script src=\\\\\"[!--news.url--]skin/WwwNetCom/js/jquery.superslide.js\\\\\" type=\\\\\"text/javascript\\\\\"></script>\r\n	<script src=\\\\\"[!--news.url--]skin/WwwNetCom/js/base.js\\\\\" type=\\\\\"text/javascript\\\\\"></script>\r\n	<link href=\\\\\"[!--news.url--]search/css/style.css\\\\\" rel=\\\\\"stylesheet\\\\\"/>\r\n</head>\r\n<body>\r\n[!--temp.nethead--]\r\n<div class=\\\\\"SearchWrap pubW center\\\\\">\r\n	<div class=\\\\\"SearchNav\\\\\">\r\n		<a href=\\\\\"[!--news.url--]\\\\\">首页</a>>搜索结果<span>系统搜索到约有:<strong>[!--ecms.num--]</strong>项符合<strong>[!--keyboard--]</strong>的查询结果</span>\r\n	</div>\r\n	<div class=\\\\\"SearchStage pubW center\\\\\">\r\n		<ul class=\\\\\"square\\\\\">\r\n			[!--empirenews.listtemp--]<!--list.var1-->[!--empirenews.listtemp--]\r\n		</ul>\r\n	</div>\r\n	[!--show.page--]\r\n</div>\r\n<!--footer--> \r\n[!--temp.netfooter--]\r\n<!--footer  结束-->\r\n</body>\r\n</html>','0','0','<li><a href=\\\\\"[!--titleurl--]\\\\\">[!--title--]</a><span>[!--newstime--]</span></li>','1','11','Y-m-d H:i:s','0','0','0');");

@include("../../inc/footer.php");
?>