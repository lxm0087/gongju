<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewstable`;");
E_C("CREATE TABLE `lm_enewstable` (
  `tid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `tbname` varchar(60) NOT NULL DEFAULT '',
  `tname` varchar(60) NOT NULL DEFAULT '',
  `tsay` text NOT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  `datatbs` text NOT NULL,
  `deftb` varchar(6) NOT NULL DEFAULT '',
  `yhid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `intb` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewstable` values('1','news','新闻系统数据表','新闻系统数据表','1',',1,','1','0','1','0');");
E_D("replace into `lm_enewstable` values('9','zxmr','整形美容数据表','整形美容数据表','0',',1,','1','0','9','0');");
E_D("replace into `lm_enewstable` values('10','gylm','莱美资质','项目中心表','0',',1,','1','0','10','0');");
E_D("replace into `lm_enewstable` values('11','netcom','站点二数据表','第二个网站数据表','0',',1,','1','0','11','0');");
E_D("replace into `lm_enewstable` values('12','mobile','手机端数据表','手机端数据表','0',',1,','1','0','12','0');");
E_D("replace into `lm_enewstable` values('13','new','南昌莱美','站点','0',',1,','1','0','13','0');");

@include("../../inc/footer.php");
?>