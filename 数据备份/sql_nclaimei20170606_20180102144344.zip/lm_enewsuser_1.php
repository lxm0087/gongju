<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewsuser`;");
E_C("CREATE TABLE `lm_enewsuser` (
  `userid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `rnd` varchar(20) NOT NULL DEFAULT '',
  `adminclass` mediumtext NOT NULL,
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `styleid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `filelevel` tinyint(1) NOT NULL DEFAULT '0',
  `salt` varchar(8) NOT NULL DEFAULT '',
  `loginnum` int(10) unsigned NOT NULL DEFAULT '0',
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(20) NOT NULL DEFAULT '',
  `truename` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(120) NOT NULL DEFAULT '',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pretime` int(10) unsigned NOT NULL DEFAULT '0',
  `preip` varchar(20) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `addip` varchar(20) NOT NULL DEFAULT '',
  `userprikey` varchar(50) NOT NULL DEFAULT '',
  `salt2` varchar(20) NOT NULL DEFAULT '',
  `lastipport` varchar(6) NOT NULL DEFAULT '',
  `preipport` varchar(6) NOT NULL DEFAULT '',
  `addipport` varchar(6) NOT NULL DEFAULT '',
  `uprnd` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewsuser` values('1','admin','da4f1f69ecc1b6b8774b1a5416a63292','CxM2z5zfxHNlX37zJNwm','|','1','0','1','0','2J2SrQwy','629','1514872685','182.100.13.48','','','0','1514854540','182.100.13.48','1477444240','127.0.0.1','UVIiK7qQQgJhWGQr1MZm1pA8ac7UuOcF3cfLfj2kY55P2PVn','dVXSIqbrJaJOdwGRfGhL','14862','15368','54469','');");
E_D("replace into `lm_enewsuser` values('2','zhuxubai','b42351dcfcaf867a3c92f53b30bb4b05','OIerHMAnUmgDdjRRNRwc','|','1','0','1','0','WXNOIO95','130','1514855048','182.100.13.48','','','0','1513732719','182.100.2.63','1483230757','218.64.68.176','3nqLg3Wk6yXckHO2pKiCiMd5padmCxvuUiuOKSpQSmh7ifde','3z7cqXFSLqkdl9ps3oLY','13370','12224','1892','');");
E_D("replace into `lm_enewsuser` values('3','xqb','78e1701ffe8b5315f74f8be71ad5a221','MyGEhiAlMrAvALh2YbJN','|','1','1','1','0','T9XBFHVj','29','1492500545','218.64.68.176','','','0','1491025095','218.64.68.176','1483346884','218.64.68.176','v6XyUCQAgDCD17ZGLBsmVgKzoiUcGejK2DRawALNASCs6XmN','SsHtCZcPEWK93HmYDmv3','5265','4442','6558','');");
E_D("replace into `lm_enewsuser` values('4','laimei','66bac9813a3e5f20404aefdde2c875bf','gL8vLB7GwSzp9IC7ZBzc','|','2','1','1','0','nBvrIktu','98','1503219741','218.64.68.176','','','0','1503207821','218.64.68.176','1500356746','218.64.68.176','dLKQzFahVDd9fLuqaRJ3vtKWl9spvuhD6qfOPXFZkb4PL463','NyQPEFJGFpaJEWPYhnm3','3765','4430','62925','');");

@include("../../inc/footer.php");
?>