<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `lm_enewsuserloginck`;");
E_C("CREATE TABLE `lm_enewsuserloginck` (
  `userid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `andauth` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `lm_enewsuserloginck` values('2','64833c0266a58c8b11528069e740194d');");
E_D("replace into `lm_enewsuserloginck` values('1','be322e8dca9f40d2a64b2a65b549bb8b');");
E_D("replace into `lm_enewsuserloginck` values('3','e2bbacf45062acd9ae27022b7a002070');");
E_D("replace into `lm_enewsuserloginck` values('4','802fa3b28c7ea7e4207102598fdeb84d');");

@include("../../inc/footer.php");
?>